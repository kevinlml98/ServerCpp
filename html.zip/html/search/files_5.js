var searchData=
[
  ['targetdirectories_2etxt_319',['TargetDirectories.txt',['../_client_cpp_2cmake-build-debug_2_c_make_files_2_target_directories_8txt.html',1,'(Global Namespace)'],['../_server_cpp_2cmake-build-debug_2_c_make_files_2_target_directories_8txt.html',1,'(Global Namespace)']]]
];
