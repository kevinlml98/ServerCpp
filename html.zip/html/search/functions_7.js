var searchData=
[
  ['sendtosocket_335',['sendToSocket',['../class_cliente_socket.html#afb54e18af36d7be1957e5d37b02d7a6a',1,'ClienteSocket']]],
  ['shortdistance_336',['shortDistance',['../class_floyd_warshall.html#afcbf868801dda4d728345029859ae163',1,'FloydWarshall']]]
];
