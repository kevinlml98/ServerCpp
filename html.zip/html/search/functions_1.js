var searchData=
[
  ['clientesocket_326',['ClienteSocket',['../class_cliente_socket.html#aa234d51ec027c0bc8c69b2c7cadd70da',1,'ClienteSocket']]],
  ['cmake_5fminimum_5frequired_327',['cmake_minimum_required',['../_client_cpp_2_c_make_lists_8txt.html#aced35ce1fd0ee8961f2e2a111ba0f8c4',1,'CMakeLists.txt']]]
];
