var hierarchy =
[
    [ "ClienteSocket", "class_cliente_socket.html", null ],
    [ "FloydWarshall", "class_floyd_warshall.html", null ],
    [ "Window", null, [
      [ "Window", "class_window.html", null ]
    ] ]
];