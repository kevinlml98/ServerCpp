var _server_cpp_2main_8cpp =
[
    [ "PORT", "_server_cpp_2main_8cpp.html#a614217d263be1fb1a5f76e2ff7be19a2", null ],
    [ "main", "_server_cpp_2main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];