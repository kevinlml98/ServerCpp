var dir_38b76c2368edb86a7d259a77d636bea8 =
[
    [ "cmake-build-debug", "dir_2f1fd1c6f7c3da7718eb88a54ad21770.html", "dir_2f1fd1c6f7c3da7718eb88a54ad21770" ],
    [ "cliente_socket.h", "cliente__socket_8h.html", "cliente__socket_8h" ],
    [ "main.cpp", "_client_cpp_2main_8cpp.html", "_client_cpp_2main_8cpp" ],
    [ "ventana.h", "ventana_8h.html", [
      [ "Window", "class_window.html", "class_window" ]
    ] ]
];