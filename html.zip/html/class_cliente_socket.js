var class_cliente_socket =
[
    [ "ClienteSocket", "class_cliente_socket.html#aa234d51ec027c0bc8c69b2c7cadd70da", null ],
    [ "sendToSocket", "class_cliente_socket.html#afb54e18af36d7be1957e5d37b02d7a6a", null ]
];