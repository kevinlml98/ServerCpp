var cliente__socket_8h =
[
    [ "ClienteSocket", "class_cliente_socket.html", "class_cliente_socket" ],
    [ "PORT", "cliente__socket_8h.html#a614217d263be1fb1a5f76e2ff7be19a2", null ]
];