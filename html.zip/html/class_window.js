var class_window =
[
    [ "Window", "class_window.html#a74e6087da23d3c24e9fac0245e5ec92c", null ],
    [ "on_button_clicked", "class_window.html#a3a00ce667c5a707cab1b5569ff41c901", null ],
    [ "a_entry", "class_window.html#ad6cd317f7944e5481c8ec034c1b887f7", null ],
    [ "a_label", "class_window.html#a92e7c3255b110e2982234e8b04e3e888", null ],
    [ "b_entry", "class_window.html#a115ab5fd8d714406d3106792049016b5", null ],
    [ "b_label", "class_window.html#afa260df241170f3d5d2d7cf942324894", null ],
    [ "cs", "class_window.html#a15bb976d5a4881ec075a63a27ba806de", null ],
    [ "g_container", "class_window.html#afa0f26af61a4c3271a6ec7689707aab7", null ],
    [ "m_button", "class_window.html#a2e20c32a184554b3b66dc0541482f8ad", null ]
];